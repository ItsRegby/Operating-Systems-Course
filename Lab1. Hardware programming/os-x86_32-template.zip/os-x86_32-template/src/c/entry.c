#include "kernel/kernel.h"
#include "drivers/keyboard/keyboard.h"
#include "drivers/timer/timer.h"
#include "drivers/serial_port/serial_port.h"


//colors--------------------------------------------------
#define BLACK_COLOR 0x0
#define GREEN_COLOR 0xa
#define YELLOW_COLOR 0xe
#define RED_COLOR 0xc
#define WHITE_COLOR 0xf
#define PINK_COLOR 0xd
unsigned char cnsl_state_clrs[25 * 80];

//animation addons--------------------------------------
bool anim_sleep_continue = false;
unsigned char cnsl_state_chrs[25 * 80];
unsigned short cnsl_state_pntr = 0;

unsigned short slide_msg = 0;
unsigned char row = 0;
unsigned char col = 0;
unsigned short curr_char = 0;

unsigned short anim_offsite_X = 0;
unsigned short anim_offsite_Y = 0;
char *sleep_img = 
    "   ##   \n"
    "   ##   \n"
    "########\n"
    "   ##   \n"
    "   ##   \n"
    "   ##   \0";
unsigned short anim_size_X = 8;
unsigned short anim_size_Y = 6;
char anim_coord_X = 1;
char anim_coord_Y = 1;
// Work with files------------------------------------------


bool edit_mode = false;
unsigned char file_slot_indx = 0;

unsigned char files_names[10][75]; 
unsigned char files_slots[10][1]; // 0 - avaliable, 1 - taken
unsigned char files_content[10][2000]; //An array for storing the contents of files, a maximum of 10 files, each file up to 2000 bytes in size
unsigned short files_last_chr_indx[10][1]; // The current index of the last character in the file
unsigned char files_count = 10;

//Console addons------------------------------------------------
char *framebuffer = (char *) 0xb8000; // A pointer to the console buffer
unsigned short cursor_pointer = 0;
unsigned char *line_char = " $ ";
unsigned char line_st_ofst = 3;

//function to find the beginning of command parameters
void find_param_start(unsigned short *pntr)
{
    while (*(framebuffer + (*pntr) * 2) == ' ' && (*pntr) < cursor_pointer)
    {
        *(framebuffer + (*pntr) * 2 + 1) = BLACK_COLOR << 4 | WHITE_COLOR;
        (*pntr)++;
    }
}
//reading command parameters
void read_param(unsigned short *pntr, unsigned char *parameter)
{
    unsigned char param_indx = 0;
    while (*(framebuffer + (*pntr) * 2) != ' ' && (*pntr) < cursor_pointer)
    {
        parameter[param_indx] = *(framebuffer + (*pntr) * 2);

        param_indx++;
        (*pntr)++;
    }
    parameter[param_indx] = '\0';
}
//finding a file by name
void find_file_name(bool *same_name_file_exist, unsigned char *parameter, unsigned char *same_name_file_indx) {
    for (unsigned char file_indx = 0; file_indx < files_count && !(*same_name_file_exist); file_indx++) {
        unsigned char shift_name = 0;

        while (files_names[file_indx][shift_name] == parameter[shift_name] && files_names[file_indx][shift_name] != '\0' && parameter[shift_name] != '\0') {
            shift_name++;
        }

        if (files_names[file_indx][shift_name] == '\0' && parameter[shift_name] == '\0') {
            *same_name_file_exist = true;
            *same_name_file_indx = file_indx;
        }
    }
}

char *cmnds_names[] = {
    "help",
    "clear",
    "sleep",
    "list",
    "create",
    "edit",
    "read",
    "delete",
    "flip"
};

void cmnd_clear()
{
    clean_screen();
    cursor_pointer = 0;
    char *ver_msg = "ChristOS - v 0.0.1\n";
    print(ver_msg, BLACK_COLOR, GREEN_COLOR);
}

void cmnd_help()
{
    char *new_line = "\n";
    print(new_line, BLACK_COLOR, BLACK_COLOR);
    
    char *msg_help = "======== Welcome to the system! ========\n== You can use the following commands ==\nhelp - show help message\nclear - clean shell\nsleep - screensave mode on\nlist - show tree of files\ncreate - create new file\nedit - edit the file\nread - show file content\ndelete - delete file\n";
    print(msg_help, BLACK_COLOR, YELLOW_COLOR);
}

void cmnd_sleep()
{
    save_console_state();

    clean_screen();
    
    anim_sleep_continue = true;
}


void cmnd_list()
{
    char *new_line = "\n";

    print(new_line, BLACK_COLOR, BLACK_COLOR);

    for (unsigned char slot_indx = 0; slot_indx < files_count; slot_indx++)
    {
        for (unsigned char cntr = 0; cntr < line_st_ofst; cntr++)
        {
            char *msg_space = " ";
            print(msg_space, BLACK_COLOR, BLACK_COLOR);
        }

        char *msg = "--";
        print(msg, BLACK_COLOR, YELLOW_COLOR);

        if (files_slots[slot_indx][0] == 1)
        {
            unsigned char shift_name = 0;

            print(&files_names[slot_indx][shift_name], BLACK_COLOR, YELLOW_COLOR);
        }
        else
        {
            //slot is empty
        }

        print(new_line, BLACK_COLOR, YELLOW_COLOR);
    }
}

void cmnd_create(unsigned short *pntr_aftr_cmnd)
{
    char *new_line = "\n";
    unsigned short pntr = *pntr_aftr_cmnd;

    find_param_start(&pntr);

    unsigned char parameter[75];

    if(pntr == *pntr_aftr_cmnd || pntr == cursor_pointer) // just command or were some spaces, but still with out parameters
    {
        print(new_line, BLACK_COLOR, BLACK_COLOR);
        char *msg = "There is no parameter given\n";
        print(msg, BLACK_COLOR, RED_COLOR);
    }
    else if (pntr < cursor_pointer) 
    {
        read_param(&pntr, &parameter);

        bool same_name_file_exist = false;
        unsigned char same_name_file_indx = 0;
        // search for same name
        find_file_name(&same_name_file_exist, &parameter, &same_name_file_indx);

        if (!same_name_file_exist) // totally new name in file system
        {
            bool free_slot_exist = false;
            unsigned char free_slot = 0;
            // search for free slot
            for (unsigned char slot_indx = 0; slot_indx < files_count && !free_slot_exist; slot_indx++)
            {
                if (files_slots[slot_indx][0] == 0)
                {
                    free_slot_exist = true;
                    free_slot = slot_indx;
                }
            }

            if (!free_slot_exist) // no free slots
            {
                print(new_line, BLACK_COLOR, BLACK_COLOR);
                char *msg = "There are no slots avaliable for new file\n";
                print(msg, BLACK_COLOR, RED_COLOR);
            }
            else // free slot is founds
            {
                // create new file  
                unsigned char shift_name = 0;
                while (parameter[shift_name] != '\0')
                {
                    files_names[free_slot][shift_name] = parameter[shift_name];
                    shift_name++;
                }
                files_slots[free_slot][0] = 1;

                print(new_line, BLACK_COLOR, BLACK_COLOR);
                char *msg = "File created\n";
                print(msg, BLACK_COLOR, GREEN_COLOR);
            }
        }
        else // already have same name
        {
            print(new_line, BLACK_COLOR, BLACK_COLOR);
            char *msg = "File with same name already exists\n";
            print(msg, BLACK_COLOR, RED_COLOR);
        }
    }
}

void cmnd_edit(unsigned short *pntr_aftr_cmnd)
{
    char *new_line = "\n";
    unsigned short pntr = *pntr_aftr_cmnd;

    find_param_start(&pntr);

    unsigned char parameter[75];

    if(pntr == *pntr_aftr_cmnd || pntr == cursor_pointer) // no pntr movement - cmnd just on line end or were spaces, but still no parameter
    {
        print(new_line, BLACK_COLOR, BLACK_COLOR);
        char *msg = "There is no parameter given\n";
        print(msg, BLACK_COLOR, RED_COLOR);
        print(line_char, BLACK_COLOR, GREEN_COLOR);
    }
    else if (pntr < cursor_pointer) 
    {
        read_param(&pntr, &parameter);

        bool same_name_file_exist = false;
        unsigned char same_name_file_indx = 0;
        // search for same name
        find_file_name(&same_name_file_exist, &parameter, &same_name_file_indx);

        if (same_name_file_exist) // if file is found - go to edit mode
        {
            save_console_state();
            clean_screen();
            edit_mode = true;
            file_slot_indx = same_name_file_indx;

            char *msg = &(files_content[same_name_file_indx]);
            print(msg, BLACK_COLOR, YELLOW_COLOR);

            files_content[same_name_file_indx][files_last_chr_indx[file_slot_indx][0]] = BLACK_COLOR;
        }
        else // no such a file name
        {
            print(new_line, BLACK_COLOR, BLACK_COLOR);
            char *msg = "File with such a name does not exist\n";
            print(msg, BLACK_COLOR, RED_COLOR);
            print(line_char, BLACK_COLOR, GREEN_COLOR);
        }
    }
}

void cmnd_read(unsigned short *pntr_aftr_cmnd)
{
    char *new_line = "\n";
    unsigned short pntr = *pntr_aftr_cmnd;

    find_param_start(&pntr);

    unsigned char parameter[75];

    if(pntr == *pntr_aftr_cmnd) // no pntr movement - cmnd just on line end
    {
        print(new_line, BLACK_COLOR, BLACK_COLOR);
        char *msg = "There is no parameter given\n";
        print(msg, BLACK_COLOR, RED_COLOR);
    }
    else if (pntr == cursor_pointer) // were spaces, but still no parameter
    {
        print(new_line, BLACK_COLOR, BLACK_COLOR);
        char *msg = "There is no parameter given\n";
        print(msg, BLACK_COLOR, RED_COLOR);
    }
    else if (pntr < cursor_pointer) // were spaces, and some chars after spaces exists - parameter. save it
    {
        read_param(&pntr, &parameter);

        // answer the question: is there any file with such a name?

        bool same_name_file_exist = false;
        unsigned char same_name_file_indx = 0;
        // search for same name
        // code
        find_file_name(&same_name_file_exist, &parameter, &same_name_file_indx);

        if (same_name_file_exist) // if file is found - show its content by saved index
        {
            print(new_line, BLACK_COLOR, BLACK_COLOR);
            char *msg = &(files_content[same_name_file_indx]);
            print(msg, BLACK_COLOR, YELLOW_COLOR);

            print(new_line, BLACK_COLOR, BLACK_COLOR);
        }
        else // no such a file name
        {
            print(new_line, BLACK_COLOR, BLACK_COLOR);
            char *msg = "File with such a name does not exist\n";
            print(msg, BLACK_COLOR, RED_COLOR);
        }
    }
}

void cmnd_delete(unsigned short *pntr_aftr_cmnd)
{
    char *new_line = "\n";
    unsigned short pntr = *pntr_aftr_cmnd;

    find_param_start(&pntr);

    unsigned char parameter[75];

    if(pntr == *pntr_aftr_cmnd) // no pntr movement - cmnd just on line end
    {
        print(new_line, BLACK_COLOR, BLACK_COLOR);
        char *msg = "There is no parameter given\n";
        print(msg, BLACK_COLOR, RED_COLOR);
    }
    else if (pntr == cursor_pointer) // were spaces, but still no parameter
    {
        print(new_line, BLACK_COLOR, BLACK_COLOR);
        char *msg = "There is no parameter given\n";
        print(msg, BLACK_COLOR, RED_COLOR);
    }
    else if (pntr < cursor_pointer) // were spaces, and some chars after spaces exists - parameter. save it
    {
        read_param(&pntr, &parameter);

        // answer the question: is there any file with such a name?

        bool same_name_file_exist = false;
        unsigned char same_name_file_indx = 0;
        // search for same name
        // code
        find_file_name(&same_name_file_exist, &parameter, &same_name_file_indx);

        if (same_name_file_exist) // if file is found - delete memory, file name, char index, set slot as avaliable
        {
            // memory
            for (unsigned short shift_file = 0; shift_file < 2000; shift_file++)
            {
                files_content[same_name_file_indx][shift_file] = BLACK_COLOR;
            }

            // file name
            for (unsigned char shift_name = 0; shift_name < 75; shift_name++)
            {
                files_names[same_name_file_indx][shift_name] = BLACK_COLOR;
            }

            // char index
            files_last_chr_indx[same_name_file_indx][0] = 0;

            // file slot
            files_slots[same_name_file_indx][0] = 0;

            print(new_line, BLACK_COLOR, BLACK_COLOR);
            char *msg = "File was deleted\n";
            print(msg, BLACK_COLOR, GREEN_COLOR);
        }
        else // no such a file name
        {
            print(new_line, BLACK_COLOR, BLACK_COLOR);
            char *msg = "File with such a name does not exist\n";
            print(msg, BLACK_COLOR, RED_COLOR);
        }
    }
}
bool flip_flag = true;
int bcgr_color = BLACK_COLOR;
void flip_cmnd()
{
    char *new_line = "\n";
    print(new_line, BLACK_COLOR, BLACK_COLOR);
    if(flip_flag)
    {
        for (unsigned char row = 0; row < 25; row++)
        {
            for (unsigned char col = 0; col < 80; col++)
            {
                *(framebuffer + row * (80 * 2) + col * (2) + 1) = PINK_COLOR << 4 | WHITE_COLOR;
            }
        }
        flip_flag = false;
        bcgr_color = PINK_COLOR;
    }
    else
    {
        for (unsigned char row = 0; row < 25; row++)
        {
            for (unsigned char col = 0; col < 80; col++)
            {
                *(framebuffer + row * (80 * 2) + col * (2) + 1) = BLACK_COLOR << 4 | GREEN_COLOR;
            }
        }
        flip_flag = true;
        bcgr_color = BLACK_COLOR;
    }


}

// array of funcs pointers
void (*cmnds[])(unsigned short *) = 
{
    cmnd_help,
    cmnd_clear,
    cmnd_sleep,
    cmnd_list,
    cmnd_create,
    cmnd_edit,
    cmnd_read,
    cmnd_delete,
    flip_cmnd
};

// -----------------------------------------------------
void save_console_state()
{
    cnsl_state_pntr = cursor_pointer;

    cursor_pointer = 0;

    put_cursor(cursor_pointer);

    for (unsigned char row = 0; row < 25; row++)
    {
        for (unsigned char col = 0; col < 80; col++)
        {
            cnsl_state_chrs[row * 80 + col] = 
                *(framebuffer + row * (80 * 2) + col * (2));

            cnsl_state_clrs[row * 80 + col] = 
                *(framebuffer + row * (80 * 2) + col * (2) + 1);
        }
    }
}

void recover_console_state()
{
    anim_offsite_X = 0;
    anim_offsite_Y = 0;
    anim_coord_X = 1;
    anim_coord_Y = 1;

    cursor_pointer = cnsl_state_pntr;

    cnsl_state_pntr = 0;

    put_cursor(cursor_pointer);

    for (unsigned char row = 0; row < 25; row++)
    {
        for (unsigned char col = 0; col < 80; col++)
        {
            *(framebuffer + row * (80 * 2) + col * (2)) = cnsl_state_chrs[row * 80 + col];
            cnsl_state_chrs[row * 80 + col] = BLACK_COLOR;

            *(framebuffer + row * (80 * 2) + col * (2) + 1) = cnsl_state_clrs[row * 80 + col];
            cnsl_state_clrs[row * 80 + col] = BLACK_COLOR;
        }
    }
}

char search_command(unsigned short *pntr_ln_st)
{
    unsigned short cmnds_nums = sizeof(cmnds_names) / sizeof(cmnds_names[0]); // numbers of commands in memory
    for (unsigned short cmnd_indx = 0; cmnd_indx < cmnds_nums; cmnd_indx++) // check each command
    {
        unsigned short pntr = *pntr_ln_st;
        bool same = true;
        unsigned short cmnd_chrs_shift = 0;
        while(*(cmnds_names[cmnd_indx] + cmnd_chrs_shift) != '\0' && pntr < cursor_pointer && same)
        {
            if (*(cmnds_names[cmnd_indx] + cmnd_chrs_shift) != *(framebuffer + pntr * 2))
            {
                same = false;
            }
            
            cmnd_chrs_shift++;
            pntr++;
        }

        if (same)
        {
            if (*(cmnds_names[cmnd_indx] + cmnd_chrs_shift) != '\0')
            {
                // some part of cmnd name are same, not all cmnd
            }
            else if(pntr == cursor_pointer || framebuffer[pntr * 2] == ' ')
            {
                *pntr_ln_st = pntr;
                return cmnd_indx;
            }
        }
    }

    return -1;
};

// -----------------------------------------------------
void exception_handler(u32 interrupt, u32 error, char *message) {
    serial_log(LOG_ERROR, message);
}

void init_kernel() {
    init_gdt();
    init_idt();
    init_exception_handlers();
    init_interrupt_handlers();
    register_timer_interrupt_handler();
    register_keyboard_interrupt_handler();
    configure_default_serial_port();
    set_exception_handler(exception_handler);
    enable_interrupts();
}

void print(char *msg, unsigned char clr_bckg, unsigned char clr_fnt)
{
    while (*msg != '\0')
    {
        if (*msg == '\n')
        {
            cursor_pointer += 80 - cursor_pointer % 80;
        }
        else
        {
            *(framebuffer + cursor_pointer * 2) = *msg;
            *(framebuffer + cursor_pointer * 2 + 1) = (clr_bckg << 4) | clr_fnt;
            cursor_pointer += 1;
        }
        msg++;
        
        if (cursor_pointer > 1999)
        {
            scroll();
        }
        else
        {
            put_cursor(cursor_pointer);
        }
    }
}

// -----------------------------------------------------
void clean_screen()
{
    for (unsigned char row = 0; row < 25; row++)
    {
        for (unsigned char col = 0; col < 80; col++)
        {
            *(framebuffer + row * (80 * 2) + col * (2)) = BLACK_COLOR;
            *(framebuffer + row * (80 * 2) + col * (2) + 1) = WHITE_COLOR;
        }
    }
}

void scroll()
{
    for (unsigned char rw = 0; rw < 24; rw++)
    {
        for (unsigned char clmn = 0; clmn < 80; clmn++)
        {
            *(framebuffer + rw * (80 * 2) + clmn * (2)) = 
            *(framebuffer + (rw + 1) * (80 * 2) + clmn * (2));

            *(framebuffer + rw * (80 * 2) + clmn * (2) + 1) = 
            *(framebuffer + (rw + 1) * (80 * 2) + clmn * (2) + 1);
        }
    }

    for (unsigned char clmn = 0; clmn < 80; clmn++)
    {
        *(framebuffer + 24 * (80 * 2) + clmn * (2)) = 0x0;
        *(framebuffer + 24 * (80 * 2) + clmn * (2) + 1) = 0xf;
    }
    
    cursor_pointer = 80 * 24;
    put_cursor(cursor_pointer);
}

void put_cursor(unsigned short pos) {
    out(0x3D4, 14);
    out(0x3D5, ((pos >> 8) & 0x00FF));
    out(0x3D4, 15);
    out(0x3D5, pos & 0x00FF);
}

_Noreturn void halt_loop() {
    while (1) { halt(); }
}

void key_handler(struct keyboard_event event)
{
    if (event.key_character && event.type == EVENT_KEY_PRESSED) {
        
        if (anim_sleep_continue)
        {
            anim_sleep_continue = false;

            clean_screen();

            recover_console_state();

            char *new_line = "\n";
            print(new_line, BLACK_COLOR, BLACK_COLOR);
            print(line_char, BLACK_COLOR, GREEN_COLOR);
        }
        
        else
        {
            if (edit_mode)
            {
                if (event.key == KEY_BACKSPACE)
                {
                    if (cursor_pointer > 0) // is there any char to work with
                    {
                        // go to previous char - char, which must be deleted
                        files_last_chr_indx[file_slot_indx][0]--;

                        // delete char/line
                        // change pntr_crr, depending on char/line deletion

                        // in any case char must be deleted
                        files_content[file_slot_indx][files_last_chr_indx[file_slot_indx][0]] == BLACK_COLOR;

                        // decide, how to set pntr_curr
                        
                        // new line char
                        if (files_content[file_slot_indx][files_last_chr_indx[file_slot_indx][0]] == '\n')
                        {
                            cursor_pointer--; // go to the end of prev line

                            // while there are no chars in framebuffer or start of row reached
                            while (*(framebuffer + (cursor_pointer - 1) * 2) == BLACK_COLOR && cursor_pointer % 80 != 0)
                            {
                                cursor_pointer--;
                            }
                        }
                        else // any other char
                        {
                            cursor_pointer--;
                        }

                        // clear deleted char data in framebuffer
                        *(framebuffer + cursor_pointer * 2) = BLACK_COLOR;
                        *(framebuffer + cursor_pointer * 2 + 1) = BLACK_COLOR << 4 | WHITE_COLOR;
                        // set cursor_pointer on deleted char place
                        put_cursor(cursor_pointer);
                    }
                }
                else if (event.key == KEY_ENTER)
                {
                    // 23 - unreachable last line to show full text when file is being readed
                    if (cursor_pointer / 80 < 23)
                    {
                        files_content[file_slot_indx][files_last_chr_indx[file_slot_indx][0]] = event.key_character;
                        print(&event.key_character, bcgr_color, YELLOW_COLOR);

                        files_last_chr_indx[file_slot_indx][0]++;
                    }
                }
                else if (event.key == KEY_TAB)
                {
                    files_content[file_slot_indx][files_last_chr_indx[file_slot_indx][0]] = '\0';
                    edit_mode = false;

                    clean_screen();
                    
                    recover_console_state();

                    file_slot_indx = 0;

                    char *new_line = "\n";
                    print(new_line, BLACK_COLOR, BLACK_COLOR);
                    print(line_char, BLACK_COLOR, GREEN_COLOR);
                }
                else
                {
                    if (cursor_pointer % 80 < 79)
                    {
                        files_content[file_slot_indx][files_last_chr_indx[file_slot_indx][0]] = event.key_character;
                        print(&event.key_character, bcgr_color, YELLOW_COLOR);
                        
                        files_last_chr_indx[file_slot_indx][0]++;
                    }
                }
            }
            
            else
            {
                if (event.key == KEY_BACKSPACE)
                {
                    if (cursor_pointer % 80 > line_st_ofst)
                    {
                        cursor_pointer -= 1;
                        *(framebuffer + cursor_pointer * 2) = bcgr_color;
                        *(framebuffer + cursor_pointer * 2 + 1) = (bcgr_color << 4) | WHITE_COLOR;

                        put_cursor(cursor_pointer);
                    }
                }
                
                else if (event.key == KEY_ENTER)
                {
                    char cmnd_nmbr = 0;

                    if (cursor_pointer % 80 > line_st_ofst) // if smth was written
                    {
                        unsigned short pntr_st_ln = cursor_pointer - cursor_pointer % 80 + line_st_ofst;

                        while (*(framebuffer + pntr_st_ln * 2) == ' ' &&
                        pntr_st_ln < cursor_pointer)
                        {
                            *(framebuffer + pntr_st_ln * 2 + 1) = bcgr_color << 4 | WHITE_COLOR; // show for debug
                            pntr_st_ln++;
                        }

                        if (*(framebuffer + pntr_st_ln * 2) != bcgr_color)
                        {
                            cmnd_nmbr = search_command(&pntr_st_ln);

                            if (cmnd_nmbr > -1)
                            {
                                // Command found

                                cmnds[cmnd_nmbr](&pntr_st_ln);
                            }
                            else if (cmnd_nmbr == -1)
                            {
                                char *new_line = "\n";
                                print(new_line, bcgr_color, BLACK_COLOR);
                                char *msg_no_cmnd = "Command not found\n";
                                print(msg_no_cmnd, bcgr_color, RED_COLOR);
                            }
                        }
                        else
                        {
                            // there are no text, just spaces
                        }
                    }
                    
                    else
                    {
                        char *new_line = "\n";
                        print(new_line, bcgr_color, BLACK_COLOR);
                    }

                    // edit
                    // sleep
                    if (cmnd_nmbr != 5 &&
                        cmnd_nmbr != 2)
                    {
                        print(line_char, bcgr_color, GREEN_COLOR);
                    }
                }
                
                else
                {
                    if (cursor_pointer % 80 < 79)
                    {
                        print(&event.key_character, bcgr_color, WHITE_COLOR);
                    }
                }
            }
        }
    }
}
int slow_down_factor = 4;
int tick_counter = 0;
void timer_tick_handler()
{
    tick_counter++;
    if (anim_sleep_continue && tick_counter % slow_down_factor == 0)
    {
        clean_screen();
        
        if (anim_coord_X > 0) // right
        {
            if (anim_offsite_X + anim_size_X == 80)
            {
                anim_coord_X *= -1;
            }
            else
            {
                // keep going
            }
        }
        else // left
        {
            if (anim_offsite_X == 0)
            {
                anim_coord_X *= -1;
            }
            else
            {
                // keep going
            }
        }
        
        if (anim_coord_Y > 0) // down
        {
            if (anim_offsite_Y + anim_size_Y == 25)
            {
                anim_coord_Y *= -1;
            }
            else
            {
                // keep going
            }
        }
        else // up
        {
            if (anim_offsite_Y == 0)
            {
                anim_coord_Y *= -1;
            }
            else
            {
                // keep going
            }
        }

        anim_offsite_X += anim_coord_X;
        anim_offsite_Y += anim_coord_Y;

        // writing on screen
        slide_msg = 0;
        row = 0;
        col = 0;
        curr_char = 0;
        while (*(sleep_img + slide_msg) != '\0')
        {
            if (*(sleep_img + slide_msg) == '\n')
            {
                row++;
                col = 0;
            }
            else
            {
                curr_char = anim_offsite_Y * 80 + row * 80 + anim_offsite_X + col;
                *(framebuffer + (curr_char) * 2) = *(sleep_img + slide_msg);
                *(framebuffer + (curr_char) * 2 + 1) = (BLACK_COLOR << 4) | RED_COLOR;
                col++;
            }
            slide_msg++;
        }
    }
}

void kernel_entry() {
    init_kernel();
    keyboard_set_handler(key_handler);
    timer_set_handler(timer_tick_handler);
   
    clean_screen();

    char *ver_msg = "ChristOS - v 0.0.1\n";
    print(ver_msg, BLACK_COLOR, GREEN_COLOR);
    print(line_char, BLACK_COLOR, GREEN_COLOR);

    halt_loop();
}